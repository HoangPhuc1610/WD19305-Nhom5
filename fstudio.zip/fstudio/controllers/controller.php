<?php 
include "CategoryController.php";
include "ProductController.php";
include "HomeController.php";
include "AuthController.php";
include "DashboardController.php";
include "CartController.php";
