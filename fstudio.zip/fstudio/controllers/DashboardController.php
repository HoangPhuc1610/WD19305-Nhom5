<?php 
switch($action){
    case 'admin':
        include "views/admin/dashboard.php";
        break;
}

