<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname="fstudio";
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);


